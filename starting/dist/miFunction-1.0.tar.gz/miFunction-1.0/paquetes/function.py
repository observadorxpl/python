def isPair(number):
    return (number%2 == 0)