from setuptools import setup

setup(
    name="miFunction",
    version="1.0",
    description="Comprueba si es par o impar",
    author = "Jose",
    author_email = "observadorxpl@gmail.com",
    url="https://google.com",
    packages=["paquetes"]
)